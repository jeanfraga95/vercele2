# Exemplos de Uso

## 1. Usar em VLC Media Player

### Método 1: Adicionar URL Diretamente
1. Abra VLC Media Player
2. Vá para **Media** → **Open Network Stream** (Ctrl+N)
3. Cole a URL:
   ```
   http://seu-dominio.com/play/sportv1
   ```
4. Clique em **Play**

### Método 2: Criar Playlist M3U
Crie um arquivo `canais.m3u`:
```m3u
#EXTM3U
#EXTINF:-1, SPORTV 1
http://seu-dominio.com/play/sportv1

#EXTINF:-1, SPORTV 2
http://seu-dominio.com/play/sportv2

#EXTINF:-1, ESPN
http://seu-dominio.com/play/espn

#EXTINF:-1, GLOBO RJ
http://seu-dominio.com/play/globorj

#EXTINF:-1, BAND
http://seu-dominio.com/play/band
```

Abra em VLC: **File** → **Open File** → Selecione `canais.m3u`

## 2. Usar em Kodi

1. Instale o addon **IPTV Simple Client**
2. Configure o arquivo M3U:
   - Vá para **Settings** → **Add-ons** → **IPTV Simple Client**
   - Em **M3U Play List URL**, insira:
     ```
     http://seu-dominio.com/canais.m3u
     ```
3. Reinicie o Kodi

## 3. Integração com JavaScript/Web

### Fetch API
```javascript
// Obter link M3U8 em formato JSON
fetch('http://seu-dominio.com/play.php?channel=sportv1&format=json')
    .then(response => response.json())
    .then(data => {
        console.log('URL M3U8:', data.m3u8_url);
        console.log('Qualidades disponíveis:', data.available_qualities);
        
        // Usar em um player HTML5
        document.getElementById('video').src = data.m3u8_url;
    });
```

### Usar com HLS.js
```html
<video id="video" width="640" height="360" controls></video>

<script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>
<script>
    const video = document.getElementById('video');
    const hls = new Hls();
    
    // Obter URL do servidor
    fetch('http://seu-dominio.com/play.php?channel=sportv1&format=json')
        .then(r => r.json())
        .then(data => {
            hls.loadSource(data.m3u8_url);
            hls.attachMedia(video);
        });
</script>
```

### Usar com Video.js
```html
<video id="video" class="video-js vjs-default-skin" controls preload="auto" width="640" height="360">
    <source id="videoSource" type="application/x-mpegURL">
</video>

<script src="https://vjs.zencdn.net/7.20.3/video.min.js"></script>
<script>
    const player = videojs('video');
    
    fetch('http://seu-dominio.com/play.php?channel=sportv1&format=json')
        .then(r => r.json())
        .then(data => {
            document.getElementById('videoSource').src = data.m3u8_url;
            player.load();
        });
</script>
```

## 4. Usar em Android

### Usar com VLC for Android
1. Abra VLC for Android
2. Toque em **+** (adicionar)
3. Cole a URL:
   ```
   http://seu-dominio.com/play/sportv1
   ```

### Usar com TiviMate
1. Abra TiviMate
2. Vá para **Settings** → **Playlists**
3. Adicione URL da playlist M3U:
   ```
   http://seu-dominio.com/canais.m3u
   ```

## 5. Usar em iOS

### Usar com Infuse
1. Abra Infuse
2. Toque em **+**
3. Selecione **Stream**
4. Cole a URL:
   ```
   http://seu-dominio.com/play/sportv1
   ```

## 6. Usar em Smart TV

### LG WebOS
1. Instale um app de streaming (ex: SmartIPTV)
2. Configure a playlist M3U:
   ```
   http://seu-dominio.com/canais.m3u
   ```

### Samsung Tizen
1. Instale um app IPTV
2. Configure a URL da playlist

### Android TV
1. Instale TiviMate ou similar
2. Configure a playlist M3U

## 7. Usar em Roku

1. Instale um app de streaming (ex: Roku Media Player)
2. Use a URL direta:
   ```
   http://seu-dominio.com/play/sportv1
   ```

## 8. Usar em Firestick

1. Instale Kodi ou TiviMate
2. Configure a playlist M3U:
   ```
   http://seu-dominio.com/canais.m3u
   ```

## 9. Integração com Python

```python
import requests
import json

# Obter link M3U8
response = requests.get('http://seu-dominio.com/play.php', params={
    'channel': 'sportv1',
    'format': 'json'
})

data = response.json()
print(f"Canal: {data['channel_id']}")
print(f"URL M3U8: {data['m3u8_url']}")
print(f"Qualidades: {data['available_qualities']}")

# Usar com ffmpeg
import subprocess

url = data['m3u8_url']
output_file = 'stream.mp4'

subprocess.run([
    'ffmpeg',
    '-i', url,
    '-c', 'copy',
    '-bsf:a', 'aac_adtstoasc',
    output_file
])
```

## 10. Integração com Node.js

```javascript
const axios = require('axios');

async function getChannelLink(channelId) {
    try {
        const response = await axios.get('http://seu-dominio.com/play.php', {
            params: {
                channel: channelId,
                format: 'json'
            }
        });
        
        console.log('URL M3U8:', response.data.m3u8_url);
        console.log('Qualidades:', response.data.available_qualities);
        
        return response.data.m3u8_url;
    } catch (error) {
        console.error('Erro:', error.message);
    }
}

// Usar
getChannelLink('sportv1');
```

## 11. Criar Playlist Dinâmica com PHP

```php
<?php
// playlist.php
header('Content-Type: application/x-mpegurl; charset=utf-8');

$channels = [
    'sportv1' => 'SPORTV 1',
    'sportv2' => 'SPORTV 2',
    'espn' => 'ESPN',
    'globorj' => 'GLOBO RJ',
    'band' => 'BAND'
];

echo "#EXTM3U\n";

foreach ($channels as $id => $name) {
    echo "#EXTINF:-1, $name\n";
    echo "http://seu-dominio.com/play/$id\n";
}
?>
```

Acesse: `http://seu-dominio.com/playlist.php`

## 12. Monitorar Status via API

```bash
# Ver status do sistema
curl http://seu-dominio.com/api.php?route=status | jq

# Ver logs
curl http://seu-dominio.com/api.php?route=logs | jq

# Listar canais
curl http://seu-dominio.com/api.php?route=channels | jq

# Extrair canal específico
curl -X POST http://seu-dominio.com/api.php?route=extract \
  -H "Content-Type: application/json" \
  -d '{"channel":"sportv1"}'
```

## 13. Usar com FFmpeg

```bash
# Converter stream para MP4
ffmpeg -i "http://seu-dominio.com/play/sportv1" -c copy -bsf:a aac_adtstoasc output.mp4

# Gravar stream por 1 hora
ffmpeg -i "http://seu-dominio.com/play/sportv1" -t 01:00:00 -c copy output.mp4

# Converter para diferentes resoluções
ffmpeg -i "http://seu-dominio.com/play/sportv1/FHD" \
  -vf scale=1280:720 -c:v libx264 -c:a aac output_hd.mp4
```

## 14. Usar com OBS Studio

1. Abra OBS Studio
2. Adicione uma nova fonte: **Media Source**
3. Em **Local File**, cole:
   ```
   http://seu-dominio.com/play/sportv1
   ```
4. Configure tamanho e posição
5. Comece a transmitir

## 15. Usar com Nginx como Proxy

```nginx
server {
    listen 8080;
    server_name localhost;
    
    location /stream/ {
        proxy_pass http://seu-dominio.com/play/;
        proxy_buffering off;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Acesse: `http://localhost:8080/stream/sportv1`

---

## Dicas Importantes

1. **Qualidade**: Use `/FHD` para melhor qualidade, mas requer mais banda
2. **Compatibilidade**: Nem todos os players suportam HLS. Teste antes de usar
3. **Cache**: O sistema mantém cache por 1 hora. Use `/api/extract` para forçar atualização
4. **Segurança**: Proteja sua URL com autenticação se necessário
5. **Performance**: Use CDN para distribuir o tráfego

---

**Última atualização:** Janeiro 2024
