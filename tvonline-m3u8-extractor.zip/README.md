# TV Online HD - M3U8 Extractor

Sistema completo de extração e redirecionamento de links M3U8 para canais de TV online. Fornece URLs fixas que redirecionam automaticamente para os links M3U8 mais recentes extraídos dos players disponíveis.

## 🎯 Características

- ✅ **Extração Automática**: Extrai links M3U8 dos 4 principais players (Joel, Sinal Público, RD Canais, Rede Canais TV)
- ✅ **URLs Fixas**: Cada canal tem um link fixo que não muda mesmo quando o M3U8 expira
- ✅ **Múltiplas Qualidades**: Suporta FHD, HD e SD quando disponíveis
- ✅ **Cache Inteligente**: Armazena links em cache com expiração automática
- ✅ **API RESTful**: Endpoints para gerenciar canais e extrações
- ✅ **Dashboard Admin**: Interface web para monitorar e controlar o sistema
- ✅ **Compatível**: Funciona em hospedagem simples ou VPS (ARM/x86_64)
- ✅ **Logs Detalhados**: Rastreamento completo de todas as operações

## 📋 Requisitos

### PHP
- **PHP 7.4+** (recomendado PHP 8.0+)
- Extensões obrigatórias:
  - `pdo` - Para acesso ao banco de dados SQLite
  - `pdo_sqlite` - Driver SQLite para PDO
  - `curl` (opcional, mas recomendado) - Para requisições HTTP melhoradas
  - `json` - Para manipulação de JSON

### Servidor Web
- Apache 2.4+ (com `mod_rewrite` habilitado) **OU**
- Nginx 1.14+
- PHP-FPM (para Nginx)

### Sistema Operacional
- Linux (Ubuntu, Debian, CentOS, etc.)
- Suporta arquitetura x86_64 e ARM (Raspberry Pi, etc.)

### Espaço em Disco
- Mínimo 50MB para instalação
- Espaço adicional para cache e logs (cresce lentamente)

## 🚀 Instalação

### 1. Verificar Requisitos PHP

```bash
# Verificar versão do PHP
php -v

# Verificar extensões instaladas
php -m | grep -E "pdo|sqlite|json"
```

### 2. Instalar Extensões PHP (se necessário)

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install php php-pdo php-sqlite3 php-curl php-json

# Se usar Apache
sudo apt-get install libapache2-mod-php
sudo a2enmod rewrite
sudo systemctl restart apache2

# Se usar Nginx
sudo apt-get install php-fpm
sudo systemctl restart php-fpm
```

**CentOS/RHEL:**
```bash
sudo yum install php php-pdo php-sqlite php-curl php-json

# Se usar Apache
sudo yum install httpd mod_php
sudo systemctl restart httpd

# Se usar Nginx
sudo yum install nginx php-fpm
sudo systemctl restart nginx php-fpm
```

### 3. Fazer Download do Sistema

```bash
# Clone ou faça download dos arquivos
git clone https://github.com/seu-usuario/tvonline-m3u8-extractor.git
cd tvonline-m3u8-extractor

# Ou extraia o arquivo ZIP
unzip tvonline-m3u8-extractor.zip
cd tvonline-m3u8-extractor
```

### 4. Configurar Permissões

```bash
# Dar permissão de escrita para diretórios
chmod 755 .
chmod 777 data logs cache

# Se usar Apache
sudo chown -R www-data:www-data .
```

### 5. Configurar Servidor Web

**Apache (com .htaccess):**
```bash
# Verificar se mod_rewrite está habilitado
sudo a2enmod rewrite

# Reiniciar Apache
sudo systemctl restart apache2
```

**Nginx:**
```nginx
server {
    listen 80;
    server_name seu-dominio.com;
    root /caminho/para/tvonline-m3u8-extractor;
    
    index index.php;
    
    location / {
        try_files $uri $uri/ @php;
    }
    
    location @php {
        rewrite ^/play/([a-zA-Z0-9_-]+)/?$ /play.php?channel=$1 last;
        rewrite ^/play/([a-zA-Z0-9_-]+)/([a-zA-Z0-9]+)/?$ /play.php?channel=$1&quality=$2 last;
        rewrite ^/api/([a-zA-Z0-9_-]+)/?$ /api.php?route=$1 last;
        fastcgi_pass unix:/run/php-fpm.sock;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }
    
    location ~ \.php$ {
        fastcgi_pass unix:/run/php-fpm.sock;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }
    
    # Proteger arquivos sensíveis
    location ~ \.(db|sqlite|log)$ {
        deny all;
    }
}
```

## 📖 Como Usar

### Acessar o Sistema

```
http://seu-dominio.com/
```

### Dashboard Admin

Acesse o painel de administração:
```
http://seu-dominio.com/admin.html
```

Aqui você pode:
- Ver status de todos os canais
- Extrair canais manualmente
- Visualizar estatísticas e logs
- Monitorar taxa de sucesso

### Usar os Links Fixos

Cada canal tem um link fixo que pode ser usado em qualquer player:

```
# Qualidade padrão (HD)
http://seu-dominio.com/play/sportv1

# Qualidade específica
http://seu-dominio.com/play/sportv1/FHD
http://seu-dominio.com/play/sportv1/HD
http://seu-dominio.com/play/sportv1/SD

# Obter JSON com link e qualidades disponíveis
http://seu-dominio.com/play.php?channel=sportv1&format=json
```

### Canais Disponíveis

```
ESPORTES:
- sportv1, sportv2, sportv3
- espn, espn2, espn3, espn4, espn5, espn6
- band (Band Sports)

TV ABERTA:
- globorj, globosp, globomg, globors, globopb, globope, globoam, globoes, globoce
- band

INFANTIL:
- gloob
- 24h_chaves, 24h_dragonball, 24h_naruto, 24h_simpsons, 24h_odeiachris
```

## 🔌 API RESTful

### Endpoints Disponíveis

#### 1. Listar Canais
```bash
GET /api/channels

Resposta:
{
  "success": true,
  "total": 128,
  "channels": {
    "sportv1": {
      "id": "sportv1",
      "name": "SPORTV 1",
      "category": "esportes",
      "logo": "https://...",
      "cached": true
    }
  }
}
```

#### 2. Status do Sistema
```bash
GET /api/status

Resposta:
{
  "success": true,
  "cached_channels": 45,
  "statistics": {
    "total_extractions": 1250,
    "successful": 1200,
    "failed": 50,
    "success_rate": "96%",
    "avg_extraction_time_ms": 2345.67
  },
  "recent_extractions": [...]
}
```

#### 3. Extrair Canal Específico
```bash
POST /api/extract
Content-Type: application/json

{
  "channel": "sportv1"
}

Resposta:
{
  "success": true,
  "message": "Extração realizada com sucesso",
  "data": {
    "channel_id": "sportv1",
    "m3u8_url": "https://...",
    "qualities": {
      "FHD": "https://...",
      "HD": "https://...",
      "SD": "https://..."
    },
    "player": "joel",
    "extraction_time": 1234
  }
}
```

#### 4. Extrair Todos os Canais
```bash
GET /api/extract

Resposta:
{
  "success": true,
  "total": 128,
  "successful": 120,
  "results": {...}
}
```

#### 5. Logs
```bash
GET /api/logs?limit=50&channel=sportv1

Resposta:
{
  "success": true,
  "total": 50,
  "logs": [
    {
      "id": 1,
      "channel_id": "sportv1",
      "status": "SUCCESS",
      "extraction_time": 1234,
      "extracted_at": "2024-01-15 10:30:45"
    }
  ]
}
```

## ⏰ Atualização Automática (Cron)

Para manter o cache sempre atualizado, configure uma tarefa cron:

```bash
# Editar crontab
crontab -e

# Adicionar a linha (executa a cada 30 minutos)
*/30 * * * * /usr/bin/php /caminho/para/cron-update.php >> /caminho/para/logs/cron.log 2>&1

# Ou a cada hora
0 * * * * /usr/bin/php /caminho/para/cron-update.php >> /caminho/para/logs/cron.log 2>&1
```

Verificar se a tarefa foi adicionada:
```bash
crontab -l
```

## 🔧 Configuração Avançada

Edite `config.php` para personalizar:

```php
// Duração do cache (em segundos)
define('CACHE_DURATION', 3600); // 1 hora

// Timeout de extração (em segundos)
define('EXTRACTION_TIMEOUT', 30);

// Número máximo de tentativas
define('MAX_RETRIES', 3);

// User Agent para requisições
define('USER_AGENT', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)...');
```

## 📊 Estrutura de Banco de Dados

O sistema usa SQLite com 3 tabelas:

### channels
```sql
- id (INTEGER PRIMARY KEY)
- channel_id (TEXT UNIQUE)
- name (TEXT)
- category (TEXT)
- logo (TEXT)
- created_at (DATETIME)
- updated_at (DATETIME)
```

### m3u8_cache
```sql
- id (INTEGER PRIMARY KEY)
- channel_id (TEXT)
- m3u8_url (TEXT)
- quality (TEXT: FHD, HD, SD)
- player_source (TEXT)
- extracted_at (DATETIME)
- expires_at (DATETIME)
- is_active (BOOLEAN)
```

### extraction_log
```sql
- id (INTEGER PRIMARY KEY)
- channel_id (TEXT)
- status (TEXT: SUCCESS, FAILED)
- error_message (TEXT)
- extraction_time (INTEGER: ms)
- extracted_at (DATETIME)
```

## 🐛 Troubleshooting

### Erro: "Banco de dados não pode ser criado"
```bash
# Verificar permissões
ls -la data/
chmod 777 data logs cache

# Verificar se SQLite está instalado
php -m | grep sqlite
```

### Erro: "Nenhum player funcionou"
- Verificar conexão com internet
- Os players podem estar offline ou bloqueados
- Aumentar `EXTRACTION_TIMEOUT` em `config.php`

### Erro: "mod_rewrite não habilitado" (Apache)
```bash
sudo a2enmod rewrite
sudo systemctl restart apache2
```

### Logs vazios ou não atualizando
```bash
# Verificar permissões dos logs
chmod 777 logs/

# Verificar se o cron está rodando
sudo systemctl status cron
```

## 📝 Logs

Os logs são salvos em `logs/extractor.log`:

```bash
# Ver logs em tempo real
tail -f logs/extractor.log

# Ver últimas 50 linhas
tail -50 logs/extractor.log

# Buscar erros
grep ERROR logs/extractor.log
```

## 🔒 Segurança

- ✅ Arquivos `.db`, `.sqlite` e `.log` são protegidos (acesso negado)
- ✅ Entrada do usuário é sanitizada
- ✅ CORS habilitado para integração com outros domínios
- ✅ Sem autenticação padrão (adicione se necessário)

## 📱 Uso em VPS/Hospedagem

### Hospedagem Compartilhada
1. Fazer upload dos arquivos via FTP/SFTP
2. Configurar permissões via gerenciador de arquivos
3. Adicionar cron job via painel de controle

### VPS Linux
```bash
# SSH na VPS
ssh usuario@seu-vps.com

# Clonar repositório
git clone https://github.com/seu-usuario/tvonline-m3u8-extractor.git

# Seguir instruções de instalação acima
```

### Docker (Opcional)
```dockerfile
FROM php:8.0-apache

RUN docker-php-ext-install pdo pdo_sqlite

COPY . /var/www/html/

RUN a2enmod rewrite

EXPOSE 80
```

## 🤝 Contribuindo

Contribuições são bem-vindas! Por favor:
1. Faça um Fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo LICENSE para detalhes.

## ⚠️ Disclaimer

Este sistema é fornecido "como está" para fins educacionais. O usuário é responsável por:
- Verificar a legalidade do uso em sua jurisdição
- Respeitar os direitos autorais dos conteúdos
- Cumprir os termos de serviço dos provedores de streaming

## 📞 Suporte

Para problemas, dúvidas ou sugestões:
- Abra uma Issue no GitHub
- Consulte a documentação
- Verifique os logs do sistema

---

**Versão:** 1.0.0  
**Última atualização:** Janeiro 2024  
**Autor:** TV Online HD Team
