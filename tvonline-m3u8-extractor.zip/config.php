<?php
/**
 * TV Online HD - M3U8 Extractor
 * Sistema de Extração e Redirecionamento de Links M3U8
 * 
 * Configurações Principais
 */

// Configurações de Banco de Dados
define('DB_PATH', __DIR__ . '/data/channels.db');
define('DB_DIR', __DIR__ . '/data');

// Configurações de Cache
define('CACHE_DURATION', 3600); // 1 hora em segundos
define('CACHE_DIR', __DIR__ . '/cache');

// Configurações de Log
define('LOG_DIR', __DIR__ . '/logs');
define('LOG_FILE', LOG_DIR . '/extractor.log');

// Configurações de Extração
define('EXTRACTION_TIMEOUT', 30); // Timeout em segundos
define('MAX_RETRIES', 3); // Número máximo de tentativas
define('USER_AGENT', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');

// URLs dos Players (conforme o site tvonlinehd.com.br)
$PLAYERS = [
    'joel' => 'https://joel.embedtv.live/',
    'sinalpublico' => 'https://sinalpublicoetv.vercel.app/?id=',
    'rdcanais' => 'https://rdcanais.com/',
    'redecanaistv' => 'https://redecanaistv.be/player3/ch.php?canal='
];

// Mapeamento de Canais
$CHANNELS = [
    'sportv1' => [
        'name' => 'SPORTV 1',
        'category' => 'esportes',
        'logo' => 'https://d1muf25xaso8hp.cloudfront.net/https://embedtv.live/assets/images/sportv.png',
        'players' => ['joel' => 'sportv', 'sinalpublico' => 'sportv1', 'rdcanais' => 'sportv', 'redecanaistv' => 'sportv1']
    ],
    'sportv2' => [
        'name' => 'SPORTV 2',
        'category' => 'esportes',
        'logo' => 'https://d1muf25xaso8hp.cloudfront.net/https://embedtv.live/assets/images/sportv2.png',
        'players' => ['joel' => 'sportv2', 'sinalpublico' => 'sportv2', 'rdcanais' => 'sportv2', 'redecanaistv' => 'sportv2']
    ],
    'sportv3' => [
        'name' => 'SPORTV 3',
        'category' => 'esportes',
        'logo' => 'https://d1muf25xaso8hp.cloudfront.net/https://embedtv.live/assets/images/sportv3.png',
        'players' => ['joel' => 'sportv3', 'sinalpublico' => 'sportv3', 'rdcanais' => 'sportv3', 'redecanaistv' => 'sportv3']
    ],
    'espn' => [
        'name' => 'ESPN',
        'category' => 'esportes',
        'logo' => 'https://d1muf25xaso8hp.cloudfront.net/https://embedtv.live/assets/images/espn.png',
        'players' => ['joel' => 'espn', 'sinalpublico' => 'espn1', 'rdcanais' => 'espn', 'redecanaistv' => 'espn']
    ],
    'globorj' => [
        'name' => 'GLOBO RJ',
        'category' => 'tv-aberta',
        'logo' => 'https://d1muf25xaso8hp.cloudfront.net/https://embedtv.live/assets/images/globo.png',
        'players' => ['joel' => 'globorj', 'sinalpublico' => 'globorj', 'rdcanais' => 'globorj', 'redecanaistv' => 'boborj']
    ],
    'globosp' => [
        'name' => 'GLOBO SP',
        'category' => 'tv-aberta',
        'logo' => 'https://d1muf25xaso8hp.cloudfront.net/https://embedtv.live/assets/images/globo.png',
        'players' => ['joel' => 'globosp', 'sinalpublico' => 'globosp', 'rdcanais' => 'globosp', 'redecanaistv' => 'bobosp']
    ],
    'band' => [
        'name' => 'BAND',
        'category' => 'tv-aberta',
        'logo' => 'https://d1muf25xaso8hp.cloudfront.net/https://embedtv.live/assets/images/band.png',
        'players' => ['joel' => 'band', 'sinalpublico' => 'band', 'rdcanais' => 'band', 'redecanaistv' => 'band']
    ]
];

// Criar diretórios necessários
if (!is_dir(DB_DIR)) mkdir(DB_DIR, 0755, true);
if (!is_dir(CACHE_DIR)) mkdir(CACHE_DIR, 0755, true);
if (!is_dir(LOG_DIR)) mkdir(LOG_DIR, 0755, true);

// Função de Log
function logMessage($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "[$timestamp] [$level] $message\n";
    file_put_contents(LOG_FILE, $logEntry, FILE_APPEND);
}

// Inicializar banco de dados
function initDatabase() {
    if (!file_exists(DB_PATH)) {
        $db = new PDO('sqlite:' . DB_PATH);
        
        // Tabela de Canais
        $db->exec("
            CREATE TABLE IF NOT EXISTS channels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                logo TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Tabela de Links M3U8 em Cache
        $db->exec("
            CREATE TABLE IF NOT EXISTS m3u8_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id TEXT NOT NULL,
                m3u8_url TEXT NOT NULL,
                quality TEXT DEFAULT 'HD',
                player_source TEXT,
                extracted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                expires_at DATETIME,
                is_active BOOLEAN DEFAULT 1,
                FOREIGN KEY(channel_id) REFERENCES channels(channel_id)
            )
        ");
        
        // Tabela de Histórico de Extrações
        $db->exec("
            CREATE TABLE IF NOT EXISTS extraction_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id TEXT NOT NULL,
                status TEXT,
                error_message TEXT,
                extraction_time INTEGER,
                extracted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(channel_id) REFERENCES channels(channel_id)
            )
        ");
        
        logMessage('Banco de dados inicializado com sucesso');
    }
}

// Conectar ao banco de dados
function getDatabase() {
    try {
        $db = new PDO('sqlite:' . DB_PATH);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $db;
    } catch (PDOException $e) {
        logMessage('Erro ao conectar ao banco de dados: ' . $e->getMessage(), 'ERROR');
        return null;
    }
}

// Inicializar banco de dados na primeira execução
initDatabase();
?>
