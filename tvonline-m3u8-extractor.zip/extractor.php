<?php
/**
 * M3U8 Extractor
 * Extrai links m3u8 dos players disponíveis
 */

require_once __DIR__ . '/config.php';

class M3U8Extractor {
    private $db;
    private $players = [];
    private $channels = [];
    
    public function __construct() {
        global $PLAYERS, $CHANNELS;
        $this->db = getDatabase();
        $this->players = $PLAYERS;
        $this->channels = $CHANNELS;
    }
    
    /**
     * Extrai link m3u8 de um player específico
     */
    public function extractFromPlayer($playerUrl, $timeout = EXTRACTION_TIMEOUT) {
        try {
            $context = stream_context_create([
                'http' => [
                    'timeout' => $timeout,
                    'user_agent' => USER_AGENT,
                    'follow_location' => true,
                    'max_redirects' => 5
                ],
                'https' => [
                    'timeout' => $timeout,
                    'user_agent' => USER_AGENT,
                    'follow_location' => true,
                    'max_redirects' => 5
                ]
            ]);
            
            $html = @file_get_contents($playerUrl, false, $context);
            
            if ($html === false) {
                return null;
            }
            
            // Procurar por padrões de m3u8
            $m3u8Patterns = [
                '/https?:\/\/[^\s"\'<>]+\.m3u8[^\s"\'<>]*/i',
                '/url:\s*["\']?(https?:\/\/[^\s"\'<>]+\.m3u8)["\']?/i',
                '/src=[\'"](https?:\/\/[^\s"\'<>]+\.m3u8)[\'"]/i',
                '/href=[\'"](https?:\/\/[^\s"\'<>]+\.m3u8)[\'"]/i'
            ];
            
            foreach ($m3u8Patterns as $pattern) {
                if (preg_match_all($pattern, $html, $matches)) {
                    foreach ($matches[0] as $match) {
                        $url = trim($match, '\'"');
                        if ($this->validateM3U8($url)) {
                            return $url;
                        }
                    }
                }
            }
            
            return null;
        } catch (Exception $e) {
            logMessage('Erro ao extrair de player: ' . $e->getMessage(), 'ERROR');
            return null;
        }
    }
    
    /**
     * Valida se a URL é um m3u8 válido
     */
    private function validateM3U8($url) {
        try {
            $context = stream_context_create([
                'http' => [
                    'timeout' => 10,
                    'user_agent' => USER_AGENT,
                    'method' => 'HEAD'
                ],
                'https' => [
                    'timeout' => 10,
                    'user_agent' => USER_AGENT,
                    'method' => 'HEAD'
                ]
            ]);
            
            $headers = @get_headers($url, 1, $context);
            
            if ($headers === false) {
                return false;
            }
            
            $contentType = isset($headers['Content-Type']) ? 
                (is_array($headers['Content-Type']) ? end($headers['Content-Type']) : $headers['Content-Type']) : '';
            
            return strpos($contentType, 'application/vnd.apple.mpegurl') !== false || 
                   strpos($contentType, 'application/x-mpegURL') !== false ||
                   strpos($url, '.m3u8') !== false;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Extrai qualidades do m3u8
     */
    public function extractQualities($m3u8Url) {
        try {
            $context = stream_context_create([
                'http' => ['timeout' => 10, 'user_agent' => USER_AGENT],
                'https' => ['timeout' => 10, 'user_agent' => USER_AGENT]
            ]);
            
            $content = @file_get_contents($m3u8Url, false, $context);
            
            if ($content === false) {
                return ['HD' => $m3u8Url];
            }
            
            $qualities = [];
            $lines = explode("\n", $content);
            
            foreach ($lines as $i => $line) {
                if (strpos($line, '#EXT-X-STREAM-INF') !== false) {
                    // Procurar por RESOLUTION
                    if (preg_match('/RESOLUTION=(\d+)x(\d+)/', $line, $matches)) {
                        $width = (int)$matches[1];
                        $height = (int)$matches[2];
                        
                        // Classificar qualidade
                        if ($height >= 1080) {
                            $quality = 'FHD';
                        } elseif ($height >= 720) {
                            $quality = 'HD';
                        } else {
                            $quality = 'SD';
                        }
                        
                        // Próxima linha contém a URL
                        if (isset($lines[$i + 1])) {
                            $qualityUrl = trim($lines[$i + 1]);
                            if (!empty($qualityUrl) && strpos($qualityUrl, '#') === false) {
                                // Converter URL relativa em absoluta
                                if (strpos($qualityUrl, 'http') === false) {
                                    $basePath = dirname($m3u8Url);
                                    $qualityUrl = $basePath . '/' . $qualityUrl;
                                }
                                $qualities[$quality] = $qualityUrl;
                            }
                        }
                    }
                }
            }
            
            // Se não encontrou qualidades específicas, retornar o m3u8 original
            if (empty($qualities)) {
                $qualities['HD'] = $m3u8Url;
            }
            
            return $qualities;
        } catch (Exception $e) {
            return ['HD' => $m3u8Url];
        }
    }
    
    /**
     * Extrai m3u8 para um canal específico
     */
    public function extractChannel($channelId) {
        if (!isset($this->channels[$channelId])) {
            logMessage("Canal não encontrado: $channelId", 'WARNING');
            return false;
        }
        
        $channel = $this->channels[$channelId];
        $startTime = microtime(true);
        
        logMessage("Iniciando extração para: {$channel['name']}");
        
        // Tentar cada player
        foreach ($channel['players'] as $playerName => $playerParam) {
            if (!isset($this->players[$playerName])) {
                continue;
            }
            
            $playerUrl = $this->players[$playerName] . $playerParam;
            logMessage("Tentando player: $playerName - $playerUrl");
            
            for ($retry = 0; $retry < MAX_RETRIES; $retry++) {
                $m3u8Url = $this->extractFromPlayer($playerUrl);
                
                if ($m3u8Url) {
                    $qualities = $this->extractQualities($m3u8Url);
                    $extractionTime = (int)((microtime(true) - $startTime) * 1000);
                    
                    // Salvar no cache
                    $this->saveToCache($channelId, $m3u8Url, $qualities, $playerName, $extractionTime);
                    
                    logMessage("Extração bem-sucedida para $channelId em {$extractionTime}ms via $playerName");
                    
                    return [
                        'success' => true,
                        'channel_id' => $channelId,
                        'm3u8_url' => $m3u8Url,
                        'qualities' => $qualities,
                        'player' => $playerName,
                        'extraction_time' => $extractionTime
                    ];
                }
                
                if ($retry < MAX_RETRIES - 1) {
                    sleep(2); // Aguardar antes de tentar novamente
                }
            }
        }
        
        $extractionTime = (int)((microtime(true) - $startTime) * 1000);
        logMessage("Falha na extração para $channelId após {$extractionTime}ms", 'ERROR');
        
        // Registrar falha
        $this->logExtraction($channelId, 'FAILED', 'Nenhum player funcionou', $extractionTime);
        
        return false;
    }
    
    /**
     * Salva m3u8 no cache
     */
    private function saveToCache($channelId, $m3u8Url, $qualities, $playerSource, $extractionTime) {
        try {
            // Limpar cache anterior
            $this->db->prepare("
                UPDATE m3u8_cache 
                SET is_active = 0 
                WHERE channel_id = ? AND is_active = 1
            ")->execute([$channelId]);
            
            // Inserir novo cache
            foreach ($qualities as $quality => $url) {
                $expiresAt = date('Y-m-d H:i:s', time() + CACHE_DURATION);
                
                $this->db->prepare("
                    INSERT INTO m3u8_cache 
                    (channel_id, m3u8_url, quality, player_source, expires_at, is_active) 
                    VALUES (?, ?, ?, ?, ?, 1)
                ")->execute([$channelId, $url, $quality, $playerSource, $expiresAt]);
            }
            
            // Registrar sucesso
            $this->logExtraction($channelId, 'SUCCESS', null, $extractionTime);
            
        } catch (PDOException $e) {
            logMessage('Erro ao salvar cache: ' . $e->getMessage(), 'ERROR');
        }
    }
    
    /**
     * Registra tentativa de extração
     */
    private function logExtraction($channelId, $status, $errorMessage = null, $extractionTime = 0) {
        try {
            $this->db->prepare("
                INSERT INTO extraction_log 
                (channel_id, status, error_message, extraction_time) 
                VALUES (?, ?, ?, ?)
            ")->execute([$channelId, $status, $errorMessage, $extractionTime]);
        } catch (PDOException $e) {
            logMessage('Erro ao registrar extração: ' . $e->getMessage(), 'ERROR');
        }
    }
    
    /**
     * Extrai todos os canais
     */
    public function extractAllChannels() {
        $results = [];
        
        foreach ($this->channels as $channelId => $channel) {
            $result = $this->extractChannel($channelId);
            $results[$channelId] = $result ?: ['success' => false, 'channel_id' => $channelId];
        }
        
        return $results;
    }
    
    /**
     * Obtém m3u8 em cache
     */
    public function getCachedM3U8($channelId, $quality = 'HD') {
        try {
            $stmt = $this->db->prepare("
                SELECT m3u8_url FROM m3u8_cache 
                WHERE channel_id = ? AND quality = ? AND is_active = 1 
                AND (expires_at IS NULL OR expires_at > datetime('now'))
                ORDER BY extracted_at DESC 
                LIMIT 1
            ");
            
            $stmt->execute([$channelId, $quality]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result ? $result['m3u8_url'] : null;
        } catch (PDOException $e) {
            logMessage('Erro ao obter cache: ' . $e->getMessage(), 'ERROR');
            return null;
        }
    }
    
    /**
     * Obtém todas as qualidades disponíveis para um canal
     */
    public function getAvailableQualities($channelId) {
        try {
            $stmt = $this->db->prepare("
                SELECT DISTINCT quality FROM m3u8_cache 
                WHERE channel_id = ? AND is_active = 1 
                AND (expires_at IS NULL OR expires_at > datetime('now'))
                ORDER BY quality DESC
            ");
            
            $stmt->execute([$channelId]);
            $results = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            return $results ?: ['HD'];
        } catch (PDOException $e) {
            logMessage('Erro ao obter qualidades: ' . $e->getMessage(), 'ERROR');
            return ['HD'];
        }
    }
}

// Se executado diretamente
if (php_sapi_name() === 'cli') {
    $extractor = new M3U8Extractor();
    
    if (isset($argv[1])) {
        $result = $extractor->extractChannel($argv[1]);
        echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    } else {
        echo "Uso: php extractor.php <channel_id>\n";
        echo "Exemplo: php extractor.php sportv1\n";
    }
}
?>
