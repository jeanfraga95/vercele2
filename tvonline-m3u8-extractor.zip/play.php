<?php
/**
 * Play.php
 * Fornece links fixos para cada canal
 * Uso: play.php?channel=sportv1&quality=HD
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/extractor.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Tratamento de OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Obter parâmetros
$channelId = isset($_GET['channel']) ? sanitizeInput($_GET['channel']) : null;
$quality = isset($_GET['quality']) ? sanitizeInput($_GET['quality']) : 'HD';
$format = isset($_GET['format']) ? sanitizeInput($_GET['format']) : 'redirect';

// Validar entrada
if (!$channelId) {
    respondWithError('Canal não especificado', 400);
}

$extractor = new M3U8Extractor();

// Tentar obter do cache
$m3u8Url = $extractor->getCachedM3U8($channelId, $quality);

// Se não estiver em cache ou expirou, tentar extrair
if (!$m3u8Url) {
    logMessage("Cache expirado ou não encontrado para $channelId, iniciando extração");
    
    $result = $extractor->extractChannel($channelId);
    
    if ($result && $result['success']) {
        $m3u8Url = $extractor->getCachedM3U8($channelId, $quality);
        
        // Se qualidade específica não disponível, tentar HD
        if (!$m3u8Url && $quality !== 'HD') {
            $m3u8Url = $extractor->getCachedM3U8($channelId, 'HD');
        }
    }
}

// Se ainda não encontrou, retornar erro
if (!$m3u8Url) {
    respondWithError("Não foi possível obter link para o canal: $channelId", 503);
}

// Responder conforme formato solicitado
if ($format === 'json') {
    header('Content-Type: application/json');
    $qualities = $extractor->getAvailableQualities($channelId);
    echo json_encode([
        'success' => true,
        'channel_id' => $channelId,
        'quality' => $quality,
        'm3u8_url' => $m3u8Url,
        'available_qualities' => $qualities,
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_SLASHES);
} else {
    // Redirecionar para o m3u8
    header('Location: ' . $m3u8Url);
    exit;
}

/**
 * Sanitiza entrada do usuário
 */
function sanitizeInput($input) {
    return preg_replace('/[^a-zA-Z0-9_-]/', '', $input);
}

/**
 * Responde com erro
 */
function respondWithError($message, $statusCode = 400) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => $message,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    exit;
}
?>
