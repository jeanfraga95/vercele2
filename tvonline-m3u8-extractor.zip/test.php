<?php
/**
 * Test.php
 * Script de teste para validar a instalação
 */

echo "=== TV Online HD - Teste de Instalação ===\n\n";

$errors = [];
$warnings = [];
$success = [];

// 1. Verificar versão do PHP
echo "1. Verificando PHP...\n";
$phpVersion = phpversion();
if (version_compare($phpVersion, '7.4.0', '>=')) {
    $success[] = "PHP $phpVersion (OK)";
} else {
    $errors[] = "PHP $phpVersion (Requer 7.4+)";
}

// 2. Verificar extensões
echo "2. Verificando extensões...\n";
$requiredExtensions = ['pdo', 'json'];
$optionalExtensions = ['curl', 'sqlite3'];

foreach ($requiredExtensions as $ext) {
    if (extension_loaded($ext)) {
        $success[] = "Extensão $ext (OK)";
    } else {
        $errors[] = "Extensão $ext não encontrada (OBRIGATÓRIA)";
    }
}

foreach ($optionalExtensions as $ext) {
    if (extension_loaded($ext)) {
        $success[] = "Extensão $ext (OK)";
    } else {
        $warnings[] = "Extensão $ext não encontrada (Opcional)";
    }
}

// 3. Verificar PDO SQLite
echo "3. Verificando PDO SQLite...\n";
$drivers = PDO::getAvailableDrivers();
if (in_array('sqlite', $drivers)) {
    $success[] = "PDO SQLite disponível (OK)";
} else {
    $errors[] = "PDO SQLite não disponível (CRÍTICO)";
}

// 4. Verificar permissões de diretórios
echo "4. Verificando permissões...\n";
$dirs = ['data', 'logs', 'cache'];
foreach ($dirs as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    
    if (is_writable($dir)) {
        $success[] = "Diretório $dir é gravável (OK)";
    } else {
        $errors[] = "Diretório $dir não é gravável";
    }
}

// 5. Testar banco de dados
echo "5. Testando banco de dados...\n";
try {
    require_once __DIR__ . '/config.php';
    $db = getDatabase();
    
    if ($db) {
        $success[] = "Conexão com banco de dados (OK)";
        
        // Verificar tabelas
        $tables = ['channels', 'm3u8_cache', 'extraction_log'];
        foreach ($tables as $table) {
            $result = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='$table'");
            if ($result->fetch()) {
                $success[] = "Tabela $table existe (OK)";
            } else {
                $warnings[] = "Tabela $table não encontrada";
            }
        }
    } else {
        $errors[] = "Falha ao conectar ao banco de dados";
    }
} catch (Exception $e) {
    $errors[] = "Erro ao testar banco de dados: " . $e->getMessage();
}

// 6. Testar arquivo de configuração
echo "6. Verificando configuração...\n";
if (defined('DB_PATH')) {
    $success[] = "Configuração carregada (OK)";
} else {
    $errors[] = "Configuração não carregada";
}

// 7. Testar extrator
echo "7. Testando extrator...\n";
try {
    require_once __DIR__ . '/extractor.php';
    $extractor = new M3U8Extractor();
    $success[] = "Classe M3U8Extractor carregada (OK)";
} catch (Exception $e) {
    $errors[] = "Erro ao carregar extrator: " . $e->getMessage();
}

// 8. Verificar arquivo .htaccess
echo "8. Verificando .htaccess...\n";
if (file_exists('.htaccess')) {
    $success[] = "Arquivo .htaccess encontrado (OK)";
} else {
    $warnings[] = "Arquivo .htaccess não encontrado (Necessário para Apache)";
}

// 9. Verificar espaço em disco
echo "9. Verificando espaço em disco...\n";
$freeSpace = disk_free_space('.');
if ($freeSpace > 52428800) { // 50MB
    $success[] = "Espaço disponível: " . formatBytes($freeSpace) . " (OK)";
} else {
    $warnings[] = "Espaço disponível: " . formatBytes($freeSpace) . " (Recomendado 50MB+)";
}

// 10. Testar função de log
echo "10. Testando logs...\n";
try {
    logMessage("Teste de log", "INFO");
    if (file_exists(LOG_FILE)) {
        $success[] = "Sistema de log funcionando (OK)";
    } else {
        $errors[] = "Sistema de log não funcionando";
    }
} catch (Exception $e) {
    $errors[] = "Erro ao testar logs: " . $e->getMessage();
}

// Exibir resultados
echo "\n\n=== RESULTADOS ===\n\n";

if (!empty($success)) {
    echo "✓ SUCESSO (" . count($success) . "):\n";
    foreach ($success as $msg) {
        echo "  ✓ $msg\n";
    }
    echo "\n";
}

if (!empty($warnings)) {
    echo "⚠ AVISOS (" . count($warnings) . "):\n";
    foreach ($warnings as $msg) {
        echo "  ⚠ $msg\n";
    }
    echo "\n";
}

if (!empty($errors)) {
    echo "✗ ERROS (" . count($errors) . "):\n";
    foreach ($errors as $msg) {
        echo "  ✗ $msg\n";
    }
    echo "\n";
}

// Resumo
echo "=== RESUMO ===\n";
echo "Sucessos: " . count($success) . "\n";
echo "Avisos: " . count($warnings) . "\n";
echo "Erros: " . count($errors) . "\n\n";

if (empty($errors)) {
    echo "✓ Sistema pronto para usar!\n";
    echo "\nPróximos passos:\n";
    echo "1. Acesse http://seu-dominio.com/admin.html\n";
    echo "2. Clique em 'Extrair Todos' para popular o cache\n";
    echo "3. Use os links fixos em seus players\n";
} else {
    echo "✗ Existem erros que precisam ser corrigidos antes de usar o sistema.\n";
    echo "\nPara mais informações, consulte o README.md\n";
}

/**
 * Formata bytes em unidades legíveis
 */
function formatBytes($bytes) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));
    
    return round($bytes, 2) . ' ' . $units[$pow];
}
?>
