<?php
/**
 * Index.php
 * Página inicial do sistema
 */

require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TV Online HD - M3U8 Extractor</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            max-width: 600px;
            width: 100%;
            padding: 40px;
        }
        
        h1 {
            color: #333;
            margin-bottom: 10px;
            text-align: center;
        }
        
        .subtitle {
            color: #666;
            text-align: center;
            margin-bottom: 30px;
        }
        
        .section {
            margin-bottom: 30px;
        }
        
        .section h2 {
            color: #667eea;
            font-size: 18px;
            margin-bottom: 15px;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }
        
        .code-block {
            background: #f5f5f5;
            border-left: 4px solid #667eea;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            overflow-x: auto;
        }
        
        .link-list {
            list-style: none;
        }
        
        .link-list li {
            margin: 10px 0;
        }
        
        .link-list a {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .link-list a:hover {
            text-decoration: underline;
        }
        
        .button-group {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-top: 20px;
        }
        
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background: #f0f0f0;
            color: #333;
        }
        
        .btn-secondary:hover {
            background: #e0e0e0;
        }
        
        .info-box {
            background: #e3f2fd;
            border-left: 4px solid #2196F3;
            padding: 15px;
            border-radius: 5px;
            margin: 15px 0;
        }
        
        .info-box strong {
            color: #1976D2;
        }
        
        @media (max-width: 600px) {
            .container {
                padding: 20px;
            }
            
            .button-group {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📺 TV Online HD</h1>
        <p class="subtitle">Sistema de Extração e Redirecionamento de Links M3U8</p>
        
        <div class="section">
            <h2>🚀 Começar</h2>
            <div class="button-group">
                <a href="admin.html" class="btn btn-primary">📊 Dashboard Admin</a>
                <a href="api.php?route=channels" class="btn btn-secondary">📡 API de Canais</a>
            </div>
        </div>
        
        <div class="section">
            <h2>📖 Como Usar</h2>
            <p>O sistema fornece links fixos para cada canal. Exemplos:</p>
            <div class="code-block">
# Redirecionar para m3u8 (qualidade padrão HD)
https://seu-dominio.com/play/sportv1

# Redirecionar para qualidade específica
https://seu-dominio.com/play/sportv1/FHD

# Obter JSON com link e qualidades disponíveis
https://seu-dominio.com/play.php?channel=sportv1&format=json
            </div>
        </div>
        
        <div class="section">
            <h2>📋 Canais Disponíveis</h2>
            <div class="code-block">
sportv1, sportv2, sportv3
espn, espn2, espn3, espn4, espn5, espn6
globorj, globosp, globomg, globors, globopb, globope, globoam, globoes, globoce
band
            </div>
        </div>
        
        <div class="section">
            <h2>🔗 Endpoints da API</h2>
            <ul class="link-list">
                <li><a href="api.php?route=channels">📡 GET /api/channels</a> - Lista todos os canais</li>
                <li><a href="api.php?route=status">📊 GET /api/status</a> - Status do sistema</li>
                <li><a href="api.php?route=logs">📝 GET /api/logs</a> - Logs recentes</li>
                <li><strong>POST /api/extract</strong> - Extrair canal específico</li>
            </ul>
        </div>
        
        <div class="info-box">
            <strong>💡 Dica:</strong> Use o Dashboard Admin para gerenciar extrações e visualizar estatísticas em tempo real.
        </div>
    </div>
</body>
</html>
