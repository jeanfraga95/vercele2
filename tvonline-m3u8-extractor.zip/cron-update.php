<?php
/**
 * Cron Update Script
 * Atualiza o cache de m3u8 periodicamente
 * 
 * Adicionar ao crontab:
 * */30 * * * * /usr/bin/php /caminho/para/cron-update.php
 * 
 * Isso executará a cada 30 minutos
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/extractor.php';

// Definir timezone
date_default_timezone_set('America/Sao_Paulo');

// Iniciar log
logMessage('=== Iniciando atualização de cache ===');

$extractor = new M3U8Extractor();
$startTime = microtime(true);

// Extrair todos os canais
$results = $extractor->extractAllChannels();

// Contar resultados
$successful = 0;
$failed = 0;

foreach ($results as $channelId => $result) {
    if ($result['success']) {
        $successful++;
        logMessage("✓ $channelId - Sucesso em {$result['extraction_time']}ms");
    } else {
        $failed++;
        logMessage("✗ $channelId - Falha", 'ERROR');
    }
}

$totalTime = (int)((microtime(true) - $startTime) * 1000);

logMessage("=== Atualização concluída ===");
logMessage("Total: " . count($results) . " | Sucesso: $successful | Falha: $failed | Tempo: {$totalTime}ms");

// Se executado via CLI, exibir resumo
if (php_sapi_name() === 'cli') {
    echo "\n=== Relatório de Atualização ===\n";
    echo "Total de canais: " . count($results) . "\n";
    echo "Sucesso: $successful\n";
    echo "Falha: $failed\n";
    echo "Tempo total: {$totalTime}ms\n";
    echo "Taxa de sucesso: " . round(($successful / count($results)) * 100, 2) . "%\n\n";
    
    if ($failed > 0) {
        echo "Canais com falha:\n";
        foreach ($results as $channelId => $result) {
            if (!$result['success']) {
                echo "  - $channelId\n";
            }
        }
    }
}
?>
