#!/bin/bash

# TV Online HD - Setup Script
# Script de instalação automatizada

echo "=========================================="
echo "TV Online HD - M3U8 Extractor"
echo "Setup Automatizado"
echo "=========================================="
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Verificar se é root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Este script deve ser executado como root (use sudo)${NC}"
    exit 1
fi

# 1. Atualizar sistema
echo -e "${YELLOW}1. Atualizando sistema...${NC}"
apt-get update -qq
apt-get upgrade -y -qq

# 2. Instalar PHP e extensões
echo -e "${YELLOW}2. Instalando PHP e extensões...${NC}"
apt-get install -y -qq php php-cli php-pdo php-sqlite3 php-curl php-json

# 3. Instalar Apache (opcional)
read -p "Deseja instalar Apache? (s/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Ss]$ ]]; then
    echo -e "${YELLOW}3. Instalando Apache...${NC}"
    apt-get install -y -qq apache2 libapache2-mod-php
    a2enmod rewrite
    systemctl restart apache2
fi

# 4. Criar diretórios
echo -e "${YELLOW}4. Criando diretórios...${NC}"
mkdir -p data logs cache
chmod 777 data logs cache

# 5. Executar teste
echo -e "${YELLOW}5. Executando teste de instalação...${NC}"
php test.php

# 6. Criar cron job
echo -e "${YELLOW}6. Configurando cron job...${NC}"
CRON_CMD="*/30 * * * * /usr/bin/php $(pwd)/cron-update.php >> $(pwd)/logs/cron.log 2>&1"
(crontab -l 2>/dev/null | grep -v "cron-update.php"; echo "$CRON_CMD") | crontab -

echo ""
echo -e "${GREEN}=========================================="
echo "✓ Instalação concluída com sucesso!"
echo "==========================================${NC}"
echo ""
echo "Próximos passos:"
echo "1. Configure seu servidor web (Apache/Nginx)"
echo "2. Acesse http://seu-dominio.com/admin.html"
echo "3. Clique em 'Extrair Todos' para popular o cache"
echo ""
echo "Para mais informações, consulte o README.md"
