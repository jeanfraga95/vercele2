<?php
/**
 * API.php
 * API RESTful para gerenciar canais e extrações
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/extractor.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Tratamento de OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Roteamento da API
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$pathParts = array_filter(explode('/', $path));

// Remover o nome do arquivo
$route = end($pathParts);

$extractor = new M3U8Extractor();
$db = getDatabase();

try {
    switch ($route) {
        case 'channels':
            handleChannels($method, $db);
            break;
            
        case 'extract':
            handleExtract($method, $extractor);
            break;
            
        case 'status':
            handleStatus($method, $db);
            break;
            
        case 'logs':
            handleLogs($method, $db);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['error' => 'Rota não encontrada']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

/**
 * Manipula requisições de canais
 */
function handleChannels($method, $db) {
    global $CHANNELS;
    
    if ($method === 'GET') {
        $channels = [];
        
        foreach ($CHANNELS as $id => $channel) {
            // Obter status do cache
            $stmt = $db->prepare("
                SELECT COUNT(*) as count FROM m3u8_cache 
                WHERE channel_id = ? AND is_active = 1 
                AND (expires_at IS NULL OR expires_at > datetime('now'))
            ");
            $stmt->execute([$id]);
            $cacheStatus = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $channels[$id] = [
                'id' => $id,
                'name' => $channel['name'],
                'category' => $channel['category'],
                'logo' => $channel['logo'],
                'cached' => $cacheStatus['count'] > 0
            ];
        }
        
        echo json_encode([
            'success' => true,
            'total' => count($channels),
            'channels' => $channels
        ]);
    }
}

/**
 * Manipula requisições de extração
 */
function handleExtract($method, $extractor) {
    if ($method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($input['channel'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Canal não especificado']);
            return;
        }
        
        $channelId = $input['channel'];
        
        logMessage("API: Iniciando extração para $channelId");
        
        $result = $extractor->extractChannel($channelId);
        
        if ($result && $result['success']) {
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'Extração realizada com sucesso',
                'data' => $result
            ]);
        } else {
            http_response_code(503);
            echo json_encode([
                'success' => false,
                'error' => 'Falha na extração',
                'channel_id' => $channelId
            ]);
        }
    } elseif ($method === 'GET') {
        // Extrair todos os canais
        logMessage("API: Iniciando extração em lote de todos os canais");
        
        $results = $extractor->extractAllChannels();
        
        $successful = array_filter($results, function($r) { return $r['success']; });
        
        echo json_encode([
            'success' => true,
            'total' => count($results),
            'successful' => count($successful),
            'results' => $results
        ]);
    }
}

/**
 * Manipula requisições de status
 */
function handleStatus($method, $db) {
    if ($method === 'GET') {
        // Contar canais com cache válido
        $stmt = $db->prepare("
            SELECT COUNT(DISTINCT channel_id) as cached_channels 
            FROM m3u8_cache 
            WHERE is_active = 1 
            AND (expires_at IS NULL OR expires_at > datetime('now'))
        ");
        $stmt->execute();
        $cacheStatus = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Últimas extrações
        $stmt = $db->prepare("
            SELECT channel_id, status, extraction_time, extracted_at 
            FROM extraction_log 
            ORDER BY extracted_at DESC 
            LIMIT 10
        ");
        $stmt->execute();
        $recentExtractions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Estatísticas
        $stmt = $db->prepare("
            SELECT 
                COUNT(*) as total_extractions,
                SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) as successful,
                SUM(CASE WHEN status = 'FAILED' THEN 1 ELSE 0 END) as failed,
                AVG(extraction_time) as avg_extraction_time
            FROM extraction_log
        ");
        $stmt->execute();
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'cached_channels' => (int)$cacheStatus['cached_channels'],
            'statistics' => [
                'total_extractions' => (int)$stats['total_extractions'],
                'successful' => (int)$stats['successful'],
                'failed' => (int)$stats['failed'],
                'success_rate' => $stats['total_extractions'] > 0 ? 
                    round(($stats['successful'] / $stats['total_extractions']) * 100, 2) . '%' : 'N/A',
                'avg_extraction_time_ms' => round($stats['avg_extraction_time'], 2)
            ],
            'recent_extractions' => $recentExtractions,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    }
}

/**
 * Manipula requisições de logs
 */
function handleLogs($method, $db) {
    if ($method === 'GET') {
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
        $channel = isset($_GET['channel']) ? $_GET['channel'] : null;
        
        $query = "SELECT * FROM extraction_log";
        $params = [];
        
        if ($channel) {
            $query .= " WHERE channel_id = ?";
            $params[] = $channel;
        }
        
        $query .= " ORDER BY extracted_at DESC LIMIT ?";
        $params[] = $limit;
        
        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'total' => count($logs),
            'logs' => $logs
        ]);
    }
}
?>
